<?php
	
	include("db.php");
	
	//$id = $_GET['id'];

	if(isset($_GET['id']) )
	{
		$id = $_GET['id'];
		mysqli_query($db, "delete from user_data where id='$id' ");

		$_SESSION['msg'] = "Users Delete Successfully...";
		header("location:index.php");
	}

?>