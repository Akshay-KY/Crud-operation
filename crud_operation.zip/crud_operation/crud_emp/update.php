<?php
	include("db.php");


	$id = $_GET['id'];

	$sel = mysqli_query($db, "select * from user_data where id='$id' ");

	$arr = mysqli_fetch_assoc($sel);
	//print_r($arr);
?>



<?php

	extract($_POST);

	if (isset($_POST['submit']))
	{

		$file_name = $_FILES['image']['name'];
		$file_tmp_name = $_FILES['image']['tmp_name'];
		$file_size = $_FILES['image']['size'];

		if (mysqli_query($db, "update user_data set first_name='$first_name', last_name='$last_name', image='$file_name', dob='$dob' where id='$id' ")){

			move_uploaded_file($file_tmp_name, "all_image/".$file_name);
			unlink("all_image/".$arr['image']);

			$_SESSION['msg'] = "Employee Update Successfully...";
			header("location:index.php");
		}
		else{
			$msg = "Not Update....Invalid Email id...";
		}
	}
	



?>
<style type="text/css">
		*{
			padding: 0px;
			margin: 0 auto;
		}
		table th,td{
			padding: 8px;
			width: 400px;
		}
		table th{
			width: 300px;

		}
		 input{
			width: 100%;
			height: 35px;
		}
	</style>

<form method="post" enctype="multipart/form-data" class="form form-group">
		
		<table border="1">
			<tr>
				<th colspan="2" style="text-align: center; background-color: blue; color: white;">Add Employee form</th>
				<!-- <td style="color: red; font-weight: bold;text-align: center;">
					<?php
						echo @$_SESSION['msg'];
					?>						
				</td> -->
			</tr>
			<tr>
				<th> First name</th>
				<td>
					<input type="text" name="first_name" value="<?= $arr['first_name']?>" required="">
				</td>
			</tr>

			<tr>
				<th>Last name</th>
				<td>
					<input type="text" name="last_name" value="<?= $arr['last_name']?>" required="">
				</td>
			</tr>

			<tr>
				<th>
					<h5><b>Previous Image</b></h5>
					<img src="all_image/<?= $arr['image'] ?>" style="height:40px; width:100px;">
				</th>
				<td>
					<h5>Select image</h5>
					<input type="file" name="image" value="<?= $arr['image']?>" required="">
				</td>
			</tr>

			<tr>
				<th>DOB</th>
				<td>
					<input type="date" name="dob" value="<?= $arr['dob']?>" required="">
				</td>
			</tr>

			<tr>
				<th style="text-align: center;">
					<a href="index.php">Go to Dashboard</a>
				</th>
				<td>
					<input type="submit" name="submit" value="Submit" class="btn btn-primary">
				</td>
			</tr>


		</table>



	</form>





