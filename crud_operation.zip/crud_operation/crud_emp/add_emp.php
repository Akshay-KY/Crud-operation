<?php
	include("db.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php
	extract($_POST);

	if(isset($_POST['submit']))
	{
		$file_name = $_FILES['image']['name'];
		$file_tmp_name = $_FILES['image']['tmp_name'];
		$file_size = $_FILES['image']['size'];


		if (mysqli_query($db, "insert into user_data(first_name, last_name, image, dob) values('$first_name', '$last_name', '$file_name', '$dob') "  ) ){
			move_uploaded_file($file_tmp_name, "all_image/".$file_name);

			header("location:index.php");
			$_SESSION['msg'] = "Inserted Successfully...";

		}else{
		//header("location:add_emp.php");
			$_SESSION['msg'] = "Alredy exit.....";
		}

}

?>
</head>
<body>
	<style type="text/css">
		*{
			padding: 0px;
			margin: 0 auto;
		}
		table th,td{
			padding: 8px;
			width: 400px;
		}
		table th{
			width: 300px;

		}
		 input{
			width: 100%;
			height: 35px;
		}
	</style>

	<form method="post" enctype="multipart/form-data" class="form form-group" style="margin-top: 20px;">
		
		<table border="1">
			<tr>
				<th colspan="2" style="text-align: center; background-color: blue; color: white;">Add Employee form</th>
				<!-- <td style="color: red; font-weight: bold;text-align: center;">
					<?php
						echo @$_SESSION['msg'];
					?>						
				</td> -->
			</tr>
			<tr>
				<th> First name</th>
				<td>
					<input type="text" name="first_name" required="">
				</td>
			</tr>

			<tr>
				<th>Last name</th>
				<td>
					<input type="text" name="last_name" required="">
				</td>
			</tr>

			<tr>
				<th>Image</th>
				<td>
					<input type="file" name="image" required="">
				</td>
			</tr>

			<tr>
				<th>DOB</th>
				<td>
					<input type="date" name="dob" required="">
				</td>
			</tr>

			<tr>
				<th style="text-align: center;">
					<a href="index.php">Go to Dashboard</a>
				</th>
				<td>
					<input type="submit" name="submit" value="Submit" class="btn btn-primary">
				</td>
			</tr>
    </table>
</form>
</body>
</html>