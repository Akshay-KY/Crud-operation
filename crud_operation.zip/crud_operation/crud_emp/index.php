<!DOCTYPE html>
<html>
<head>
	<title></title>
<?php
	include("db.php");
	session_destroy();
?>
</head>
<body>
<div class="container-fluid btn-danger"  style="padding: 7px 0px 2px 0px; margin-bottom: 15px;">
	<div class="col-md-3">
		<p class="text-left h4">All Users</p>
	</div>

	<div class="col-lg-3" style="font-weight: bold;margin-top: 7px;text-align: center;">
		
		<?php
			echo @$_SESSION['msg'];
			
		?>
	</div>
	<div class="col-md-6">
		
		<a href="add_emp.php" class="btn btn-success pull-right btn-sm">Add User</a>
	</div>
</div>
	
<div class="table-responsive text-nowrap" style="padding:5px">	
<?Php
	
	$sel = mysqli_query($db, "select * from user_data");
	$count = mysqli_num_rows($sel);
	

	if ($count == 0)
	{
		echo "$count / Your employee Data is Empty...";
	}
	else
	{
	?>
		<table class="table table-hover" style="border:2px solid black;">
			<tr>
				<th>S.n.</th>
				<th> First Name</th>
				<th>Last Name</th>
				<th>Image</th>
				<th>DOB</th>
				<th>Action</th>
			</tr>
		
	<?php
		$sn = 1;

		while ($arr = mysqli_fetch_assoc($sel))
		{
	?>
			
			<tr>
				<th><?= $sn ?></th>
				<td><?= $arr['first_name'] ?></td>
				<td><?= $arr['last_name'] ?></td>
				<td><img src="all_image/<?= $arr['image'] ?>" style="height:60px; width:60px;"></td>
				<td><?= $arr['dob'] ?></td>
				<td>
					<a href="update.php?id=<?= $arr['id'] ?> " class="btn btn-info btn-sm">Edit</a>
					<a href="delete.php?id=<?= $arr['id'] ?> " onclick="return confirm('Are you sure to delete employee account..') " class="btn btn-danger btn-sm">Delete</a>
				</td>
			</tr>
			


	<?php
			$sn++;
		}
	}
?>

</table>

</div>





</body>
</html>